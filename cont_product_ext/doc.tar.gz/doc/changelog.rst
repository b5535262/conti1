****** cont_product_ext ******
- Init version

'1.0'
-------
** Added extra fields as per sheet - Ankit H Gandhi.